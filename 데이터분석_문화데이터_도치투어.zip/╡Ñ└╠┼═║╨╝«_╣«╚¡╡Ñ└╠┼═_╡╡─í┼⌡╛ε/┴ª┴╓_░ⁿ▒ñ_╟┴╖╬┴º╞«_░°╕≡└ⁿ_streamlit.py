import streamlit as st
import pandas as pd
import folium
from folium.plugins import MarkerCluster
from streamlit_folium import st_folium

# Load the data
cluster_data = pd.read_csv("C:/Users/USER/Desktop/공모전/공모전_군집분석_최종완성끝끝끝!!.csv")
map_data = pd.read_csv("C:/Users/USER/Desktop/공모전/맵자료정리.csv")

# 군집 스타일 요약
cluster_styles = {
    0: "기본적인 편의시설을 갖춘 중간 가격대의 호텔, 공항과 멀리 떨어진 위치.",
    1: "비즈니스 여행객을 위한 저가 호텔, 공항과 가까운 위치.",
    2: "다양한 편의시설을 갖춘 중간 가격대의 호텔, 공항과 가까운 위치.",
    3: "기본적인 편의시설을 갖춘 저가 호텔, 공항과 멀리 떨어진 위치.",
    4: "다양한 고급 편의시설을 갖춘 고가 호텔, 공항과 멀리 떨어진 위치."
}

# 군집 요약 정보를 생성
cluster_summary = cluster_data.groupby('군집').agg({
    '편의시설': 'first',
    '주변 관광지': 'first',
    '가격대': 'first',
    '공항과의 거리': 'first'
}).reset_index()

# Streamlit app
st.title("호텔 군집 분석 및 추천 시스템")

st.header("원하시는 호텔 유형을 선택하세요")

# Initialize session state for selected cluster and hotel
if 'selected_cluster' not in st.session_state:
    st.session_state.selected_cluster = None
if 'selected_hotel' not in st.session_state:
    st.session_state.selected_hotel = None

# 군집별 버튼 생성
for _, row in cluster_summary.iterrows():
    cluster_label = f"{row['군집']}유형 - {cluster_styles[row['군집']]}"
    if st.button(cluster_label):
        st.session_state.selected_cluster = row['군집']
        st.session_state.selected_hotel = None  # 새로운 군집 선택 시 호텔 초기화

# 선택된 군집이 있을 때만 호텔 시각화
if st.session_state.selected_cluster is not None:
    selected_cluster = st.session_state.selected_cluster
    st.subheader(f"{selected_cluster}유형 호텔 시각화")

    # 선택한 군집의 호텔들 필터링
    filtered_hotels = cluster_data[cluster_data['군집'] == selected_cluster]

    # Folium map setup
    m = folium.Map(location=[33.3617, 126.5292], zoom_start=10)  # 중심 위치를 제주도로 설정

    # 호텔들 마커 추가
    marker_cluster = MarkerCluster().add_to(m)
    for idx, hotel in filtered_hotels.iterrows():
        popup_text = f"""
        호텔 이름: {hotel['숙박업명']}<br>
        관광지 수 (5km 내): {hotel['관광지_5km_내_개수']}개<br>
        객실 수 구간: {hotel['객실수_구간']}<br>
        평균 가격 구간: {hotel['평균가격_구간']}<br>
        공항과의 거리: {hotel['공항과의거리_구간']}
        """
        folium.Marker(
            location=[hotel['위도'], hotel['경도']],
            popup=folium.Popup(popup_text, max_width=300),
            icon=folium.Icon(color='blue', icon='info-sign'),
            tooltip=hotel['숙박업명']
        ).add_to(marker_cluster)

    # Folium map display
    st_folium_map = st_folium(m, width=700, height=500)

    if st_folium_map['last_object_clicked']:
        clicked_location = st_folium_map['last_object_clicked']
        lat, lng = clicked_location['lat'], clicked_location['lng']
        
        # 선택된 호텔 필터링
        selected_hotel = filtered_hotels[(filtered_hotels['위도'] == lat) & (filtered_hotels['경도'] == lng)]
        
        if not selected_hotel.empty:
            hotel_name = selected_hotel['숙박업명'].values[0]
            st.session_state.selected_hotel = {
                'name': hotel_name,
                'location': (lat, lng)
            }

# 선택된 호텔이 있을 때만 주변 관광지 시각화
if st.session_state.selected_hotel is not None:
    hotel_info = st.session_state.selected_hotel
    selected_hotel_location = hotel_info['location']
    hotel_name = hotel_info['name']
    st.subheader(f"{hotel_name} 주변 5km 이내 관광지 시각화")

    # Folium map setup
    m = folium.Map(location=selected_hotel_location, zoom_start=13)

    # 선택된 호텔 마커 추가
    folium.Marker(
        location=selected_hotel_location,
        popup=f"선택된 호텔: {hotel_name}",
        icon=folium.Icon(color='blue', icon='info-sign')
    ).add_to(m)

    # 5km 반경의 관광지 표시
    for _, tourist_spot in map_data.iterrows():
        distance = ((selected_hotel_location[0] - tourist_spot['위도'])**2 + (selected_hotel_location[1] - tourist_spot['경도'])**2)**0.5
        if distance <= 0.05:  # 대략적인 5km 반경
            popup_text = f"""
            관광지명: {tourist_spot['관광지명']}<br>
            관광지 분류: {tourist_spot['관광지분류']}<br>
            주소: {tourist_spot['주소']}<br>
            운영 상세사항: {tourist_spot['운영상세사항']}<br>
            관광지 설명: {tourist_spot['관광지설명']}
            """
            folium.Marker(
                location=[tourist_spot['위도'], tourist_spot['경도']],
                popup=folium.Popup(popup_text, max_width=300),
                icon=folium.Icon(color='green', icon='info-sign')
            ).add_to(m)

    # Folium map display
    st_folium(m, width=700, height=500)